﻿using ConsoleApp1.Exercise5_CitySchool;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace ConsoleApp1.Exercise5_CitySchool
{
    internal class RunExercise5
    {
        public static void Run()
        {

            City City1 = new City
            {
                Name = "Amman",
                Region = "Central",
                Schools = new List<School>
    {
        new School
        {
            Name = "AbdullahII",
            Capacity = 25,
            Teachers = new List<Teacher>
            {
                new Teacher { Name = "RAMA", id = "123" },
                new Teacher { Name = "Ali", id = "124" }
            }
        },
        new School
        {
            Name = "Zarqa School",
            Capacity = 30,
            Teachers = new List<Teacher>
            {
                new Teacher { Name = "Sara", id = "125" },
                new Teacher { Name = "Lana", id = "126" },
                new Teacher { Name="mohmmed", id="140"}
            }
        }
    }
            };
            City city2 = new City
            {
                Name = "Irbid",
                Region = "North",
                Schools = new List<School>
                {
                    new School
                    {
                        Name="Irbid"
                        , Capacity = 25,
                        Teachers =new  List<Teacher>
                        {
                            new Teacher
                            {
                                Name="Ahmad",
                                id="2008"
                            }


                        }
                    },
                     new School
                      {
                        Name = "Al-Ajloune School",
                        Capacity = 30,
                        Teachers = new List<Teacher>
                        {
                         new Teacher { Name = "Khale", id = "130" },
                        new Teacher { Name = "Roa'a", id = "131" },
                        new Teacher {Name="Omar",id="200"}
                        }
                     }
                }
            };
            var allCities = new List<City> { City1, city2 };

            var service = new CityService(allCities);
            service.PrintCityStructure();
            service.GetSchoolWithMostTeachers();
        }
       


    }
}