﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1.Exercise5_CitySchool
{
    internal class City:School
    {
        public string? Name { get; set; }
        public List<School>? Schools { get; set; }
       public string? Region { get; set; }

    }
}
