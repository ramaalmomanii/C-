﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1.Exercise5_CitySchool
{
    internal class School:Teacher
    {
        public string? SName { get; set; }
        public int Capacity { get; set; }
        public List<Teacher> Teachers { get; set; } = new List<Teacher>();
    }
}
