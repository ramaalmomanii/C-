﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace ConsoleApp1.Exercise5_CitySchool
{
    internal class CityService
    {
        private readonly IEnumerable<City> _cities;

        public CityService(IEnumerable<City> cities)
        {
            _cities = cities;
        }
        public void PrintCityStructure()
        {
            foreach (City city in _cities)
            {
                Console.WriteLine($"City: {city.Name} ({city.Region})");

                foreach (var school in city.Schools)
                {
                    Console.WriteLine($"  School: {school.Name} (Capacity: {school.Capacity})");

                    foreach (var teacher in school.Teachers)
                    {
                        Console.WriteLine($"    Teacher: {teacher.Name} - {teacher.id}");
                    }
                }

                Console.WriteLine("-------------------");
            }
        }
        public void GetSchoolWithMostTeachers()
        {
            var result = _cities.SelectMany(city => city.Schools.Select(
                school => new
                {
                    CityName = city.Name,
                    School = school,
                    TeacherCount = school.Teachers.Count
                }))
                .OrderByDescending(x => x.TeacherCount)
                .FirstOrDefault();

            if (result != null)
            {
                Console.WriteLine("School with most teachers:");
                Console.WriteLine($"City: {result.CityName}");
                Console.WriteLine($"School: {result.School.Name}");
                Console.WriteLine($"Teachers: {result.TeacherCount}");
                Console.WriteLine($"Capacity: {result.School.Capacity}");
            }
        }
    }
}
