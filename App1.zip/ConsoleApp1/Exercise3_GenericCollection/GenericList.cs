﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Collections;

namespace ConsoleApp1.Exercise3_GenericCollection
{
    internal class GenericList<T> : IGenericList<T>
    {
        /* manages a backing array */
        public T[] items = new T[4]; 
        private int count = 0;
        public void Add(T item)
        {
            if (count == items.Length)
            {
                // Resize the array if it's full
                Array.Resize(ref items, items.Length * 2);
            }
            items.SetValue(item, count);
            count++;
        }
        public void Clear() { 
            Array.Clear(items, 0, count);
        }
        public T FirstOrDefault()
        {
            if (count == 0)
            {
                return default(T); // Return default value for T if the list is empty
            }
            return (T)items.GetValue(0); // Return the first item
        }
        public int Count
        {
            get { return count; } // Return the number of items in the list
        }
        public T this[int index]
        {
            get
            {
                if (index < 0 || index >= count)
                {
                    throw new ArgumentOutOfRangeException(nameof(index), "Index is out of range.");
                }
                return (T)items.GetValue(index); // Return the item at the specified index
            }
        }
        public IEnumerator<T> GetEnumerator()
        {
            for (int i = 0; i < count; i++)
            {
                yield return (T)items.GetValue(i); // Yield each item in the list
            }
        }
        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }


    }

}

