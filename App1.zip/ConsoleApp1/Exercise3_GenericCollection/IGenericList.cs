﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1.Exercise3_GenericCollection
{
     public interface IGenericList<T> : IEnumerable<T>
    {
        /*Methods: 
▪ void Add(T item) 
▪ T FirstOrDefault() 
▪ int Count { get; } */
        public void Add(T item);
        T FirstOrDefault();
        public int Count { get; }
        T this[int index] { get; }

    }
}
