﻿using System;

namespace ConsoleApp1.Exercise3_GenericCollection
{
    internal class RunExercise3
    {
        public static void Run()
        {
            Console.WriteLine("Welcome to Generic Collection Exercise!");

            // Create a new generic list of integers
            GenericList<int> intList = new GenericList<int>();
            intList.Add(10);
            intList.Add(11);
            intList.Add(12);
            intList.Add(13);
            intList.Add(20);
            intList.Add(30);

            Console.WriteLine("Integer List:");
            foreach (var item in intList)
            {
                Console.WriteLine(item);
            }

            // Create a new generic list of strings
            GenericList<string> stringList = new GenericList<string>();
            try
            {
                stringList.Add("Hello");
                stringList.Add(null); // رح ترمي Exception حسب متطلبات التمرين
            }
            catch (ArgumentNullException ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }

            stringList.Add("World");
            stringList.Add("Generic");
            stringList.Add("Collection");
            stringList.Add("Example");

            Console.WriteLine("\nString List:");
            foreach (var item in stringList)
            {
                Console.WriteLine(item);
            }

            // Demonstrate FirstOrDefault
            Console.WriteLine($"\nFirst item in int list: {intList.FirstOrDefault()}");
            Console.WriteLine($"First item in string list: {stringList.FirstOrDefault()}");

            // Clear the integer list
            intList.Clear();
            Console.WriteLine($"\nInteger List Count after clearing: {intList.Count}");
            stringList.Clear();
            Console.WriteLine($"String List Count after clearing: {stringList.Count}");

            // Exception handling for index out of range
            try
            {
                Console.WriteLine(intList[-1]);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }

            try
            {
                Console.WriteLine(stringList[2]); // ممكن يرمي IndexOutOfRange
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }
        }
    }
}
