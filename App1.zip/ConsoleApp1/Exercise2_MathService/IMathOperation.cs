﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1.Exercise2_MathService
{
    internal interface IMathOperation
    {
        public OperationResult Execute(decimal? x, decimal? y);
    }
   
}
