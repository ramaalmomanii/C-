﻿using ConsoleApp1.Exercise1_CarsStore;
using ConsoleApp1.Exercise1_CarsStore.ConsoleApp1.Exercise1_CarsStore;
using System;

namespace ConsoleApp1.Exercise2_MathService
{
    internal class RunExercise2
    {
        public static void Run()
        {
            MathService mathService = new MathService();

            // Register built-in operations
            mathService.Register("add", new Addition());
            mathService.Register("sub", new Subtraction());
            mathService.Register("mul", new Multiplication());
            mathService.Register("div", new Division());
            mathService.Register("pow", new Exponentiation());
            mathService.Register("sqrt", new SquareRoot());

            Console.WriteLine("=== Robust Math Service ===");

            while (true)
            {
                mathService.ListOperations();
                Console.WriteLine("Type operation name (or 'exit' to quit): ");
                string? opName = Console.ReadLine()?.ToLower();

                if (opName == "exit") break;

                decimal? x = null;
                decimal? y = null;

                Console.Write("Enter first number: ");
                string? input1 = Console.ReadLine();
                try
                {
                    x = Convert.ToDecimal(input1);
                }
                catch
                {
                    Console.WriteLine("⚠️ Invalid input for first number. Treated as 0.");
                    x = 0;
                }

                if (opName != "sqrt")
                {
                    Console.Write("Enter second number: ");
                    string? input2 = Console.ReadLine();
                    try
                    {
                        y = Convert.ToDecimal(input2);
                    }
                    catch
                    {
                        Console.WriteLine("⚠️ Invalid input for second number. Treated as 0.");
                        y = 0;
                    }
                }


                var result = mathService.Calculate(opName, x, y);

                if (result.Success)
                    Console.WriteLine($"✅ Result: {result.Value}");
                else
                    Console.WriteLine($"❌ Error: {result.ErrorMessage}");

                Console.WriteLine("-----------------------------");
            }

            Console.WriteLine("Thanks for using Math Service! 👋");
        }
    }
}
