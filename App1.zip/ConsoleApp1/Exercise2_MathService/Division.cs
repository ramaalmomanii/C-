﻿using System;

namespace ConsoleApp1.Exercise2_MathService
{
    internal class Division : IMathOperation
    {
        public OperationResult Execute(decimal? x, decimal? y)
        {
            decimal val1 = x ?? 0;
            decimal val2 = y ?? 0;

            if (val2 == 0)//decimal never throws an exception for division by zero, but we handle it gracefully here
            {
                return new OperationResult
                {
                    Success = false,
                    ErrorMessage = "Cannot divide by zero."
                };
            }

            return new OperationResult
            {
                Success = true,
                Value = val1 / val2
            };
        }
    }
}
