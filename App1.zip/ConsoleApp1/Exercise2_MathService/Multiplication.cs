﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1.Exercise2_MathService
{
    internal class Multiplication:IMathOperation
    {
        public OperationResult Execute(decimal? x, decimal? y)
        {
            // Null = 0 fallback
            decimal val1 = x ?? 0;
            decimal val2 = y ?? 0;

            return new OperationResult
            {
                Success = true,
                Value = val1 * val2
            };
        }
    }
}
