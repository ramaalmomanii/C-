﻿using System;
using System.Collections.Generic;

namespace ConsoleApp1.Exercise2_MathService
{
    internal class MathService
    {
        private readonly Dictionary<string, IMathOperation> operations = new();

        
        public void Register(string name, IMathOperation operation)
        {
            operations[name.ToLower()] = operation;
        }

       
        public OperationResult Calculate(string operationName, decimal? x, decimal? y)
        {
            if (operations.TryGetValue(operationName.ToLower(), out var operation))
            {
                return operation.Execute(x, y);
            }
            else
            {
                return new OperationResult
                {
                    Success = false,
                    ErrorMessage = $"Operation '{operationName}' not found."
                };
            }
        }

        
        public void ListOperations()
        {
            Console.WriteLine("Available operations:");
            foreach (var op in operations.Keys)
            {
                Console.WriteLine($"- {op}");
            }
        }
    }
}
