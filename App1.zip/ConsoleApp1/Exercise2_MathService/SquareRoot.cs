﻿using System;

namespace ConsoleApp1.Exercise2_MathService
{
    internal class SquareRoot : IMathOperation
    {
        public OperationResult Execute(decimal? x, decimal? y)
        {
            
            decimal val = x ?? 0;

            if (val < 0 && x.HasValue)
            {
                return new OperationResult
                {
                    Success = false,
                    ErrorMessage = "Cannot compute square root of a negative number."
                };
            }

            double sqrtResult = Math.Sqrt((double)val);

            return new OperationResult
            {
                Success = true,
                Value = (decimal)sqrtResult
            };
        }
    }
}
