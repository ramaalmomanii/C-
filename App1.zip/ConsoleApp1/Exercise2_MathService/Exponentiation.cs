﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1.Exercise2_MathService
{
    internal class Exponentiation:IMathOperation
    {
        public OperationResult Execute(decimal? x, decimal? y)
        {
            if (!x.HasValue || !y.HasValue)
            {
                return new OperationResult
                {
                    Success = false,
                    ErrorMessage = "Both base and exponent must be provided."
                };
            }
            double result = Math.Pow((double)x.Value, (double)y.Value);
            return new OperationResult
            {
                Success = true,
                Value = (decimal)result
            };
        }
    }
    
}
