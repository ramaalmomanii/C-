﻿using ConsoleApp1.Exercise1_CarsStore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1.Exercise1_CarsStore
{
    internal class CarOnSale : Car
    {
        public IDiscountStrategy? DiscountStrategy { get; set; }
        public  decimal?  FinalPrice => DiscountStrategy.ApplyDiscount((decimal)BasePrice);
       
        public  override string ToString()
        {
            return $"Car Make: {Make}, Model: {Model}, Base Price: {BasePrice:C}, Final Price: {FinalPrice:C}";

        }
    }
}
