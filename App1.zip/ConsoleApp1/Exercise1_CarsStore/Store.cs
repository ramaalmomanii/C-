﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1.Exercise1_CarsStore
{
    internal abstract class Store
    {
        public string? Name { get; set; }
        public string? Location { get; set; }
        public string? OwnerName { get; set; }
        public Store() 
        { 
            Name = "R.K.M";
            Location = "Jordan-Amman";
            OwnerName = "Rama AL-Momani";
        }
        public abstract void DisplayDetails();
        

    }
   
}
