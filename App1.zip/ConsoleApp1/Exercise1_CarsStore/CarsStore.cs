﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1.Exercise1_CarsStore
{
    internal class CarsStore : Store
    {
        public List<Car> Inventory { get; set; }= new List<Car>();
        public override void DisplayDetails()
        {
            Console.WriteLine($"Store Name: {Name}");
            Console.WriteLine($"Location: {Location}");
            Console.WriteLine($"Owner: {OwnerName}");
        }

        public  void ListInventory()
        {
            if (Inventory.Count == 0 || Inventory is null)
            {
                Console.WriteLine("No cars available in the inventory.");
                return;
            }
            else
            {
                Console.WriteLine("Listing inventory...");
                foreach (var car in Inventory)
                {
                    car.DisplayDetails();
                    Console.WriteLine("-------------------------");
                }
            }
            // Implementation for listing inventory goes here
            

        }
    }
}
