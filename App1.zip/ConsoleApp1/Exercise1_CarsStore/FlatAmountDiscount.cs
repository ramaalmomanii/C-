﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1.Exercise1_CarsStore
{
    internal class FlatAmountDiscount:IDiscountStrategy
            {
        private  decimal flatAmount;
        public FlatAmountDiscount(decimal flatAmount)
        {
            this.flatAmount = flatAmount;
        }
        public decimal ApplyDiscount(decimal basePrice)
        {
            return basePrice - flatAmount >=0 ? basePrice - flatAmount : 0;
        }
    }
    
 }

