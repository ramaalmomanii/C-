﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1.Exercise1_CarsStore
{
    namespace ConsoleApp1.Exercise1_CarsStore
    {
        internal static class CarFactory
        {
            public static CarOnSale CreateCar(string make, string model, decimal basePrice, IDiscountStrategy discountStrategy)
            {
                return new CarOnSale
                {
                    Make = make,
                    Model = model,
                    BasePrice = basePrice,
                    DiscountStrategy = discountStrategy
                };
            }
        }
    }

}
