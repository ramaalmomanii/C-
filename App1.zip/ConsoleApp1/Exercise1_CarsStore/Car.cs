﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1.Exercise1_CarsStore
{
    interface IProduct
    {
        void DisplayDetails();
    }
    internal class Car : IProduct

    {
        public string? Make { get; set; }
        public string? Model { get; set; }

        public decimal? BasePrice { get; set; }
        public Car()
        {
            Make = "G-Class";
            Model = "Mercedes-Benz";
            BasePrice = 100000; // Default price
        }
        public Car(string make, string model, decimal price)
        {
            Make = make;
            Model = model;
            BasePrice = price;
        }
        public void DisplayDetails()
        {
            Console.WriteLine($"Car Make: {Make}");
            Console.WriteLine($"Model: {Model}");
            Console.WriteLine($"Price: {BasePrice:C}");
            Console.WriteLine("-------------------------");

        }

        
    
    

    } 
}
