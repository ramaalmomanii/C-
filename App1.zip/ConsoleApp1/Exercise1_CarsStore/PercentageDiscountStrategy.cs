﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1.Exercise1_CarsStore
{
    internal class PercentageDiscountStrategy : IDiscountStrategy
    {
        private decimal percentage;
        public PercentageDiscountStrategy(decimal percentage)
        {
            this.percentage = percentage;
        }

        public decimal ApplyDiscount(decimal basePrice)
        {
            return basePrice - (basePrice * (percentage / 100));
        }
    }
}
