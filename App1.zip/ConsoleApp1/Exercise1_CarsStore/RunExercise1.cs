﻿using ConsoleApp1.Exercise1_CarsStore;
using ConsoleApp1.Exercise1_CarsStore.ConsoleApp1.Exercise1_CarsStore;
using System;


namespace ConsoleApp1.Exercise1_CarsStore
{
    internal class RunExercise1
    {
        public static void Run()
        {
            Console.WriteLine("Welcome to Car Store");

            Console.Write("Enter store name: ");
            string? storeName = Console.ReadLine();

            Console.Write("Enter store location: ");
            string? storeLocation = Console.ReadLine();

            Console.Write("Enter store owner name: ");
            string? ownerName = Console.ReadLine();

            var store = new CarsStore
            {
                Name = storeName,
                Location = storeLocation,
                OwnerName = ownerName
            };


            Console.Write("Enter car make: ");
            string? carMake = Console.ReadLine();

            Console.Write("Enter car model: ");
            string? carModel = Console.ReadLine();

            Console.Write("Enter car base price: ");
            decimal carPrice;
            while (!decimal.TryParse(Console.ReadLine(), out carPrice) || carPrice < 0)
            {
                Console.WriteLine("Base price must be a valid positive number.");
            }

            
            Console.WriteLine("1. Percentage Discount");
            Console.WriteLine("2. Flat Amount Discount");

            IDiscountStrategy? discountStrategy = null;
            

           
            Console.Write("Enter discount percentage: ");
                decimal percent;
                while (!decimal.TryParse(Console.ReadLine(), out percent) || percent < 0 || percent > 100)
                {
                    Console.WriteLine("Enter a valid percentage (0–100):");
                }
                discountStrategy = new PercentageDiscountStrategy(percent);

                Console.Write("Enter flat discount amount: ");
                decimal amount;
                while (!decimal.TryParse(Console.ReadLine(), out amount) || amount < 0)
                {
                    Console.WriteLine("Enter a valid non-negative amount:");
                }
                discountStrategy = new FlatAmountDiscount(amount);
           

            // factory method to create a car
            CarOnSale car = CarFactory.CreateCar(carMake, carModel, carPrice, discountStrategy);

            // add the car to the store's inventory
            store.Inventory.Add(car);

            // write the details of the store and the car inventory
            Console.WriteLine("\nStore Details:");
            store.DisplayDetails();

            Console.WriteLine("\nCar Inventory:");
            store.ListInventory();
        }
    }
}
