﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;

namespace ConsoleApp1.Exercise4_FileMerge
{
    internal class File_Merge
    {
        public static async Task MergeAsync(string src, string dst)
        {
            string srcPath = "D:\\work\\c#\\ConsoleApp1\\TextFile1.txt";
            string dstPath = "D:\\work\\c#\\ConsoleApp1\\TextFile2.txt";

            try
            {
                List<string> lines = new List<string>();
                using (StreamReader reader = new StreamReader(srcPath))
                {
                    string? line;
                    while ((line = await reader.ReadLineAsync()) != null)
                    {
                        lines.Add(line);
                    }
                    
                }


                if (!File.Exists(dstPath))
                {
                    using (File.Create(dstPath)) { }
                }


                using (StreamWriter writer = new StreamWriter(dstPath, append: true))
                {
                    foreach (var l in lines)
                    {
                        await writer.WriteLineAsync(l);
                        Console.WriteLine(l);
                    }
                }

                Console.WriteLine("File merged successfully.");

            }
            catch (IOException ex)
            {
                Console.WriteLine(" IO Error: " + ex.Message);
            }
            catch (UnauthorizedAccessException ex)
            {
                Console.WriteLine("❌ Access Error: " + ex.Message);
            }
           
        }
        public static async Task AnalyzeAsync(string filePath)
        {
            try
            {
                string content = await File.ReadAllTextAsync(filePath);

                char[] delimiters = { ' ', '\n', '\r', '\t', ',', '.', ';', ':', '-', '!', '?', '"' };

                var words = content
                    .Split(delimiters, StringSplitOptions.RemoveEmptyEntries)
                    .Select(word => word.ToLower())
                    .ToList();

                Console.WriteLine($"Total word count: {words.Count}");

                var frequency = words
                    .GroupBy(w => w)
                    .ToDictionary(g => g.Key, g => g.Count());

                var top5 = frequency
                    .OrderByDescending(kv => kv.Value)
                    .Take(5);

                Console.WriteLine("Top 5 frequent words:");
                foreach (var kv in top5)
                {
                    Console.WriteLine($"   {kv.Key} → {kv.Value}");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error analyzing file: " + ex.Message);
            }
        }


    }

}
