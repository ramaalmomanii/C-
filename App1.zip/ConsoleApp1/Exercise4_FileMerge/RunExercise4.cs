﻿using System;
using System.Threading.Tasks;

namespace ConsoleApp1.Exercise4_FileMerge
{
    internal class RunExercise4
    {
        public static async Task RunAsync()
        {
            
            string srcPath = "D:\\work\\c#\\ConsoleApp1\\TextFile1.txt";
            string dstPath = "D:\\work\\c#\\ConsoleApp1\\TextFile2.txt";

            try
            {
                
                await File_Merge.MergeAsync(srcPath, dstPath);

                
                await File_Merge.AnalyzeAsync(dstPath);
            }
            catch (Exception ex)
            {
                Console.WriteLine("❌ Unexpected error: " + ex.Message);
            }
        }
    }
}
