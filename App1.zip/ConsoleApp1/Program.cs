﻿using ConsoleApp1.Exercise1_CarsStore;
using ConsoleApp1.Exercise2_MathService;
using ConsoleApp1.Exercise3_GenericCollection;
using ConsoleApp1.Exercise4_FileMerge;
using ConsoleApp1.Exercise5_CitySchool;

namespace ConsoleApp1
{
    internal class Program
    {
        public static async Task Main(string[] args)
        {
            Console.WriteLine("Choose an Exercise to run (1 - 5):");
            Console.WriteLine("1. Cars Store");
            Console.WriteLine("2. Robust Math Service");
            Console.WriteLine("3. Generic Collection");
            Console.WriteLine("4. File Merge Service");
            Console.WriteLine("5. City School Management");

            string? choice = Console.ReadLine();

            switch (choice)
            {
                case "1":
                    RunExercise1.Run();
                    break;
                case "2":
                    RunExercise2.Run();
                    break;
                case "3":
                    RunExercise3.Run();

                    break;
                case "4":
                    await RunExercise4.RunAsync();
                    break;
                case "5":
                    RunExercise5.Run();
                    break;

                default:
                    Console.WriteLine("Invalid choice.");
                    break;
            }
        }
    }
}
